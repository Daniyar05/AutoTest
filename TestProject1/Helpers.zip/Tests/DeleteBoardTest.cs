﻿using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace TestProject1
{
    [TestFixture]
    public class DeleteBoardTest : TestBase
    {
        [Test]
        public void DeleteBoard()
        {
            AccountData user = new AccountData(
                "2qyc9@deltajohnsons.com",
                "2qyc9@deltajohnsons.com"
            );
            BoardData board = new BoardData("Board for delete");

            applicationManager.Navigation.OpenHomePage();
            applicationManager.Auth.Login(user);

            applicationManager.Navigation.OpenBoardCreationPage();
            applicationManager.Board.Create(board);

            Assert.That(applicationManager.Board.IsBoardOpened(), Is.False);

            applicationManager.Navigation.OpenDashboard();
            applicationManager.Board.OpenFirstBoard();

            applicationManager.Board.DeleteOpenedBoard();

            applicationManager.Navigation.OpenDashboard();

            Assert.That(applicationManager.Board.IsDashboardOpened(), Is.True);














        }
    }
}