﻿using System;
using System.Collections.Generic;
using System.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace TestProject1
{
    public class BoardHelper : HelperBase
    {
        public BoardHelper(ApplicationManager manager)
            : base(manager)
        {
        }

        private WebDriverWait Wait(int seconds = 10)
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
        }

        public void Create(BoardData board)
        {
            Wait().Until(ExpectedConditions.ElementIsVisible(By.Id("id_title"))).Click();

            IWebElement title = driver.FindElement(By.Id("id_title"));
            title.Clear();
            title.SendKeys(board.Title);

            Wait().Until(ExpectedConditions.ElementToBeClickable(By.Id("create"))).Click();
        }

        public bool IsCreateFormOpened()
        {
            return IsElementPresent(By.Id("id_title")) && IsElementPresent(By.Id("create"));
        }

        public bool IsDashboardOpened()
        {
            return IsElementPresent(By.Id("board-list")) || IsElementPresent(By.Id("list"));
        }

        public bool IsBoardOpened()
        {
            return IsElementPresent(By.CssSelector(".ff.ff-menu")) ||
                   IsElementPresent(By.CssSelector(".ellipsis")) ||
                   IsElementPresent(By.CssSelector(".logo span"));
        }

        public IList<IWebElement> GetBoards()
        {
            return driver.FindElements(By.CssSelector("#list .whiteboard, .whiteboard-list .whiteboard"));
        }

        public int GetBoardCount()
        {
            return GetBoards().Count;
        }

        public bool IsBoardPresent()
        {
            return GetBoardCount() > 0;
        }

        public void OpenFirstBoard()
        {
            Wait().Until(d => d.FindElements(By.CssSelector("#list .whiteboard, .whiteboard-list .whiteboard")).Count > 0);
            GetBoards().First().Click();
        }

        public string GetFirstBoardTitle()
        {
            Wait().Until(d => d.FindElements(By.CssSelector("#list .whiteboard .title, .whiteboard .title")).Count > 0);
            return driver.FindElement(By.CssSelector("#list .whiteboard .title, .whiteboard .title")).Text.Trim();
        }

        public bool IsBoardWithTitlePresent(string title)
        {
            return driver.FindElements(By.CssSelector("#list .whiteboard .title, .whiteboard .title"))
                .Any(x => x.Text.Trim() == title);
        }

        public void OpenOpenedBoardMenu()
        {
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".ff-menu"))).Click();
        }

        public void DeleteOpenedBoard()
        {
            OpenOpenedBoardMenu();
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("li:nth-child(1) > .toollink"))).Click();
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".ellipsis"))).Click();
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".admin:nth-child(7)"))).Click();
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.Name("action"))).Click();
        }
    }
}