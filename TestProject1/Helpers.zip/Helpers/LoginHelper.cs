﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace TestProject1
{
    public class LoginHelper : HelperBase
    {
        public LoginHelper(ApplicationManager manager)
            : base(manager)
        {
        }
        private WebDriverWait Wait(int seconds = 10)
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
        }

        //public void Login(AccountData user)
        //{
        //    if (IsElementPresent(By.CssSelector(".sign-in")))
        //    {
        //        Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".sign-in"))).Click();
        //    }
        //    driver.FindElement(By.Id("email")).Click();
        //    driver.FindElement(By.Id("email")).Clear();
        //    driver.FindElement(By.Id("email")).SendKeys(user.Email);

        //    driver.FindElement(By.Id("id_password")).Click();
        //    driver.FindElement(By.Id("id_password")).Clear();
        //    driver.FindElement(By.Id("id_password")).SendKeys(user.Password);

        //    driver.FindElement(By.Id("sign-in-button")).Click();
        //}
        public void Login(AccountData user)
        {
            if (IsLoggedIn())
            {
                return;
            }

            if (IsElementPresent(By.CssSelector(".sign-in")))
            {
                Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".sign-in"))).Click();
            }

            Wait().Until(d =>
                d.FindElements(By.Id("email")).Count > 0 &&
                d.FindElements(By.Id("id_password")).Count > 0 &&
                d.FindElements(By.Id("sign-in-button")).Count > 0
            );

            driver.FindElement(By.Id("email")).Click();
            driver.FindElement(By.Id("email")).Clear();
            driver.FindElement(By.Id("email")).SendKeys(user.Email);

            driver.FindElement(By.Id("id_password")).Click();
            driver.FindElement(By.Id("id_password")).Clear();
            driver.FindElement(By.Id("id_password")).SendKeys(user.Password);

            driver.FindElement(By.Id("sign-in-button")).Click();
        }

        public bool IsLoggedIn()
        {
            return IsElementPresent(By.CssSelector(".ff.ff-menu")) ||
                   IsElementPresent(By.Id("icon-logo")) ||
                   IsElementPresent(By.Id("board-list"));
        }

        public void Logout()
        {
            if (!IsLoggedIn())
            {
                return;
            }

            if (IsElementPresent(By.CssSelector(".ff.ff-menu")))
            {
                Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".ff.ff-menu"))).Click();
            }

            if (IsElementPresent(By.CssSelector("a[href='https://ideaflip.com/logout/'], a[href='/logout/']")))
            {
                Wait().Until(ExpectedConditions.ElementToBeClickable(
                    By.CssSelector("a[href='https://ideaflip.com/logout/'], a[href='/logout/']"))).Click();
            }
        }

        public void EnsureLoggedOut()
        {
            if (IsLoggedIn())
            {
                Logout();
            }
        }

    }
}
