﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;

namespace TestProject1
{
    public class NavigationHelper : HelperBase
    {
        private readonly string baseURL;

        public NavigationHelper(ApplicationManager manager, string baseURL)
            : base(manager)
        {
            this.baseURL = baseURL;
        }

        private WebDriverWait Wait(int seconds = 10)
        {
            return new WebDriverWait(driver, TimeSpan.FromSeconds(seconds));
        }

        public void OpenHomePage()
        {
            driver.Navigate().GoToUrl(baseURL);
            driver.Manage().Window.Size = new System.Drawing.Size(668, 784);
        }

        public void OpenLoginForm()
        {
            OpenHomePage();

            if (IsElementPresent(By.CssSelector(".sign-in")))
            {
                Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".sign-in"))).Click();
            }
        }

        public void OpenBoardCreationPage()
        {
            driver.Navigate().GoToUrl(baseURL + "create/");
            Wait().Until(ExpectedConditions.ElementIsVisible(By.Id("id_title")));
        }

        public void OpenDashboard()
        {
            driver.Navigate().GoToUrl(baseURL + "home/");
            Wait().Until(ExpectedConditions.ElementIsVisible(By.Id("board-list")));
        }

        public void OpenMenu()
        {
            Wait().Until(ExpectedConditions.ElementToBeClickable(By.CssSelector(".ff.ff-menu"))).Click();
        }

        public void Logout()
        {
            OpenMenu();
            Wait().Until(ExpectedConditions.ElementToBeClickable(
                By.CssSelector("a[href='https://ideaflip.com/logout/'], a[href='/logout/']"))).Click();
        }
    }
}