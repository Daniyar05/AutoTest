﻿using NUnit.Framework;

namespace TestProject1
{
    [TestFixture]
    public class CreateBoardTest : TestBase
    {
        [Test]
        public void AddBoardTest()
        {
            AccountData user = new AccountData(
                "2qyc9@deltajohnsons.com",
                "2qyc9@deltajohnsons.com"
            );

            BoardData board = new BoardData("Board_New");

            applicationManager.Auth.Login(user);
            applicationManager.Navigation.OpenBoardCreationPage();
            applicationManager.Board.Create(board);
            applicationManager.Navigation.OpenDashboard();

            Assert.That(applicationManager.Board.IsBoardWithTitlePresent(board.Title), Is.True);
        }
    }
}